package com.example.grandrpwatcher

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val requestCapture = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Grand RP Name Watcher"
            textSize = 23f
            setPadding(0, 0, 0, 12)
        }
        val info = TextView(this).apply {
            text = "When monitoring is started, Android will show its screen-sharing permission prompt and a persistent notification. A screenshot is saved when visible game text appears to announce a name change."
            textSize = 16f
            setPadding(0, 0, 0, 20)
        }
        val start = Button(this).apply {
            text = "Start monitoring"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        }
        val stop = Button(this).apply {
            text = "Stop monitoring"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                Toast.makeText(this@MainActivity, "Monitoring stopped", Toast.LENGTH_SHORT).show()
            }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 24)
            addView(title)
            addView(info)
            addView(start)
            addView(stop)
        }
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API but used for the MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            ContextCompat.startForegroundService(this, service)
            Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show()
        }
    }
}
