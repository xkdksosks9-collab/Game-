# Grand RP Name Watcher (Android starter project)

This is an Android Studio source project. It uses Android's user-approved MediaProjection screen capture and on-device ML Kit OCR to look for the specific visible Grand RP format `PlayerName changed Name to NewName` (optionally preceded by an `HH:MM` timestamp) and checks that the text pixels are bright lime/green. When detected, it saves a JPEG screenshot to `Pictures/GrandRPNameChanges`.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync and install to a physical Android device.
4. Run the app, tap **Start monitoring**, and approve Android's screen-capture prompt.
5. Open Grand RP and keep the app's persistent monitoring notification visible.
6. Tap **Stop monitoring** in the app when finished.

## Important limitations
- This is a starter implementation, not a tested APK. It must be built and tested in Android Studio.
- Detection is OCR- and color-based. It targets the supplied green-line format `PlayerName changed Name to NewName`, optionally preceded by a time such as `19:43`. It may miss messages if OCR cannot read them, the game changes the wording/color, or the line is too brief or obscured.
- Android requires explicit screen-capture approval. The ongoing notification is intentional; this app does not hide recording or capture secretly.
- Some games/device versions may block screen capture or show a protected/black screen.
- The app does not modify Grand RP, read private game data, or interact with game servers.
